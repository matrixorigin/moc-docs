平台中实例会在每小时对前一小时账户产生的消费情况出一次账并进行统一扣费，在收支明细界面您可以根据交易单号和交易时间筛选您想了解的现金收支情况，交易单号不支持模糊查询。

![](https://community-shared-data-1308875761.cos.ap-beijing.myqcloud.com/artwork/mocdocs/charing/revenue-1.png)

- 交易类型
    - 充值：对账户进行充值行为
    - 消费：实例消费产生
    - 提现：您充值到 MO Intelligence 账户的资金可以（且仅可以）用于订购 MO Intelligence 的付费实例，如果您后续不再订购，您可以通过提现的方式将余额原路退回至原付款账户。
    - 退款：当您进行退款操作，余额将退回至您的 MO Intelligence 账户中。
