# 充值

MatrixOne Intelligence 为用户提供了在线充值的方式，当前支持的充值方式有：

- 支付宝充值
- 微信充值
- 对公转账

登录实例管理平台后，点击页面顶部的**充值**按钮，弹出充值窗口。请注意，使用支付宝和微信进行充值时，每笔交易的最大限额为 5 万元。

<div align="center">
    <img src=https://community-shared-data-1308875761.cos.ap-beijing.myqcloud.com/artwork/mocdocs/charing/recharge-1.png width=60% heigth=60%/>
</div>

请注意：

- 充值完成后，如您有未结清账单（欠费），充值资金将优先抵扣未结清账单；
- 充值资金不支持直接开发票，需在云平台购买资源后，根据消费记录申请发票；
- 暂不支持在线提现功能，如您需要，可联系我们。