# 使用 Golang 连接

MatrixOne Intelligence 支持 Golang 连接，并且支持 [Go-MySQL-Driver](https://github.com/go-sql-driver/mysql)。

本篇文档将指导你了解如何使用 `Golang` 以及 `Gorm` 连接 MatrixOne Intelligence。

## 开始前准备

- 已安装 [MySQL 客户端](https://dev.mysql.com/downloads/mysql)，如果你没有安装，可以点击 [MySQL 客户端](https://dev.mysql.com/downloads/mysql)至官方网站进行下载安装。

- 已完成[创建实例](../../Instance-Mgmt/create-instance/create-serverless-instance.md)。

- 已安装 [Golang 1.18 版本及以上](https://go.dev/dl/)，如果你没有安装，可以点击 [Golang 1.18 版本及以上](https://go.dev/dl/)至官方网站进行下载安装；如果你已安装，可以使用下面的命令行检查版本：

    ```
    #检查 Golang 版本号，确认是否安装
    go version
    ```

- 已安装 [Git](https://git-scm.com/downloads) 工具，如果你没有安装，可以点击 [Git](https://git-scm.com/downloads) 至官方网站进行下载安装。

## 使用 Golang 连接 MatrixOne Intelligence 服务

`Go-MySQL-Driver` 是一个用于 Go 语言的 MySQL 驱动程序，它实现了 Go 标准库中 `database/sql` 接口的方法，使得 Go 语言程序可以通过这个驱动程序连接和操作 MySQL 数据库。

1. 安装 `Go-MySQL-Driver` 工具：

    使用 [Go Tool](https://golang.org/cmd/go/) 将 `Go-MySQL-Driver` 包安装到你的 [$GOPATH](https://github.com/golang/go/wiki/GOPATH)。

    你也可以使用下面的命令行安装 `Go-MySQL-Driver` 工具：

    ```
    > go get -u github.com/go-sql-driver/mysql
    ```

2. 使用 MySQL 客户端连接 MatrixOne Intelligence。新建一个名称为 *test* 数据库：

    ```sql
    mysql> create database test;
    ```

3. 创建一个纯文本文件 *golang_connect_matrixonecloud.go* 并将代码写入文件：

    ```go
    package main

    import (
        "database/sql"
        "fmt"
        "net/url"
        "strconv"

        _ "github.com/go-sql-driver/mysql"
    )

    func main() {
        username := "585b49fc_852b_4bd1_b6d1_d64bc1d8xxxx:admin:accountadmin" // modify this
        host := "freetier-01.cn-hangzhou.cluster.matrixonecloud.cn"      // modify this
        password := "your_password"    // modify this
        port := 6001
        database := "test"
        encodedUsername := url.QueryEscape(username)
        dsn := encodedUsername + ":" + password + "@tcp(" + host + ":" + strconv.Itoa(port) + ")/" + database
        db, _ := sql.Open("mysql", dsn) // Set database connection
        defer db.Close()                //Close DB
        err := db.Ping()                //Connect to DB
        if err != nil {
            fmt.Println("Database Connection Failed") //Connection failed
            return
        } else {
            fmt.Println("Database Connection Succeed") //Connection succeed
        }
    }

    ```

4. 打开一个终端，在终端内执行下面的命令：

    ```
    > go run golang_connect_matrixonecloud.go
    Database Connection Succeed
    ```

## 使用 Gorm 连接 MatrixOne Intelligence 服务

```gorm``` 是一个基于 golang 的一个神奇的全功能 ORM 库，我们将使用 ```gorm.io/gorm``` 和 ```gorm.io/driver/mysql``` 这两个库来让 Go 连接到 MYSQL 数据库。

1. 安装 ```gorm.io/gorm``` 和 ```gorm.io/driver/mysql``` 库，使用 ```go get``` 命令安装：

    ```
    go get -u gorm.io/gorm
    go get -u gorm.io/driver/mysql
    ```

2. 使用 MySQL 客户端连接 MatrixOne Intelligence。新建一个名称为 *test* 数据库：

    ```sql
    mysql> create database test;
    ```

3. 创建一个文本文件 *golang_gorm_connect_matrixonecloud.go* 并将代码写入文件：

    ```go
    package main

    import (
        "fmt"
        "net/url"
        "strconv"

        "gorm.io/driver/mysql"
        "gorm.io/gorm"
    )

    func getDBConn() *gorm.DB {
        username := "585b49fc_852b_4bd1_b6d1_d64bc1d8xxxx:admin:accountadmin" // modify this
        host := "freetier-01.cn-hangzhou.cluster.matrixonecloud.cn"      // modify this
        password := "your_password"    // modify this
        port := 6001
        database := "test"
        encodedUsername := url.QueryEscape(username)
        dsn := encodedUsername + ":" + password + "@tcp(" + host + ":" + strconv.Itoa(port) + ")/" + database
        db, err := gorm.Open(mysql.Open(dsn), &gorm.Config{})
        // get connection
        if err != nil {
            fmt.Println("Database Connection Failed") //Connection failed
        } else {
            fmt.Println("Database Connection Succeed") //Connection succeed
        }
        return db
    }
    func main() {
        getDBConn()
    }

    ```

4. 打开一个终端，在终端内执行下面的命令：

    ```
    > go run golang_gorm_connect_matrixonecloud.go
    Database Connection Succeed
    ```

## 参考文档

关于使用 Golang 通过 MatrixOne Intelligence 构建一个简单的 CRUD 的示例，参见 [Golang 基础示例](../Tutorial/develop-golang-crud-demo.md)。

关于使用 Gorm 通过 MatrixOne Intelligence 构建一个简单的 CRUD 的示例，参见 [Gorm 基础示例](../Tutorial/gorm-golang-crud-demo.md)。
