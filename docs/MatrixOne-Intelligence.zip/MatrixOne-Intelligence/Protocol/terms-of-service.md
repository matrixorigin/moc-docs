# 服务条款

详情请参见 [MatrixOne Intelligence 服务条款 (Terms of Service)](https://www.matrixorigin.cn/moc/terms-of-service)。
