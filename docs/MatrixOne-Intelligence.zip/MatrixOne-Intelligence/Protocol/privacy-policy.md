# 隐私政策

详情请参见 [MatrixOne Intelligence 隐私政策 (Privacy Policy)](https://www.matrixorigin.cn/moc/privacy-policy)。
