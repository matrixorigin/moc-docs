# 作业

作业是工作流执行的历史快照，即使工作流被修改或删除，这些历史执行记录仍将以作业的形式保留，并且作业不能被删除。

<div align="center">
    <img src=https://community-shared-data-1308875761.cos.ap-beijing.myqcloud.com/artwork/mocdocs/data-processing/operation-1.png
 width=100% heigth=100%/>
</div>

点击作业名称可以进入作业详情列表，用户可以查看工作流每次执行的时间、工作流当时的配置信息、文件处理状态。作业详情中还可以将处理失败的文件批量再处理一次。

<div align="center">
    <img src=https://community-shared-data-1308875761.cos.ap-beijing.myqcloud.com/artwork/mocdocs/data-processing/operat_2.png
 width=100% heigth=100%/>
</div>
