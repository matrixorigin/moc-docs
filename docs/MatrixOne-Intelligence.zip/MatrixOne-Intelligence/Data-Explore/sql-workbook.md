# 工作簿管理

你在线编辑和执行的 SQL 语句都将保存在不同的工作簿中，方便后续进一步参考和使用。

首次使用时，将默认在 default 的工作簿中进行 SQL 编辑和查询，你可以进一步修改工作簿的名称。

你也可以在工作簿列表上方点击“+”号创建新的工作簿，若工作簿数量较多同时支持搜索功能。

每个工作簿都支持多个版本，你每次编辑将生成草稿版本，点击执行后将保存为正式版本。

![Alt text](https://community-shared-data-1308875761.cos.ap-beijing.myqcloud.com/artwork/mocdocs/sqleditor/sql_editor_0.12_5.png)

!!! note
    每个 SQL User 最多可建 100 个工作簿，每个工作簿将保存最近 25 个版本。
