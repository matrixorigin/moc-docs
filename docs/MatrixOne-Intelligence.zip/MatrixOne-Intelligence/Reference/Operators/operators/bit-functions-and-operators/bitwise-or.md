# **\|**

## **运算符说明**

位运算符或，按位或。对每一对比特位执行或（OR）操作。如果 a 或 b 为 1，则 a OR b 结果为 1。

结果类型取决于参数是否为二进制字符串或数字：

- 当参数为二进制字符串类型，并且其中至少一个不是十六进制 `literal`、位 `literal` 或 `NULL literal` 时，则进行二进制字符串求值计算；否则会进行数值求值计算，并根据需要将参数转换为无符号 64 位整数。

- 二进制字符串求值产生一个与参数长度相同的二进制字符串。如果参数的长度不相等，则会发生 `ER_INVALID_BITWISE_OPERANDS_SIZE` 错误。数值计算产生一个无符号的 64 位整数。

## **语法结构**

```
> SELECT value1 | value2;
```

## **示例**

```sql
mysql> SELECT 29 | 15;
+---------+
| 29 | 15 |
+---------+
|      31 |
+---------+
1 row in set (0.01 sec)

mysql> select null | 2;
+----------+
| null | 2 |
+----------+
|     NULL |
+----------+
1 row in set (0.01 sec)

mysql> select null | 2;
+----------+
| null | 2 |
+----------+
|     NULL |
+----------+
1 row in set (0.01 sec)

create table t1(a int, b int unsigned);
insert into t1 values (-1, 1), (-5, 5);

mysql> select a | 2, b | 2 from t1;
+-------+-------+
| a | 2 | b | 2 |
+-------+-------+
|    -1 |     3 |
|    -5 |     7 |
+-------+-------+
```
