# **JOIN**

## **语法说明**

``JOIN`` 用于把来自两个或多个表的行结合起来。

下图展示了 ``LEFT JOIN``、``RIGHT JOIN``、``INNER JOIN``、和 ``OUTER JOIN``。

- ``LEFT JOIN``

|SELECT [select_list] FROM TableA A LEFT JOIN TableB B ON A.Key=B.Key|![leftjoin](https://community-shared-data-1308875761.cos.ap-beijing.myqcloud.com/artwork/docs/reference/left_join.png)|
|---|---|
|SELECT [select_list] FROM TableA A LEFT JOIN TableB B ON A.Key=B.Key WHERE B.Key IS NULL|![leftjoinwhere](https://community-shared-data-1308875761.cos.ap-beijing.myqcloud.com/artwork/docs/reference/left_join_where.png)|

- ``RIGHT JOIN``

|SELECT [select_list] FROM TableA A RIGHT JOIN TableB B ON A.Key=B.Key|![leftjoinwhere](https://community-shared-data-1308875761.cos.ap-beijing.myqcloud.com/artwork/docs/reference/right_join.png)|
|---|---|
|SELECT [select_list] FROM TableA A RIGHT JOIN TableB B ON A.Key=B.Key WHERE A.Key IS NULL|![leftjoinwhere](https://community-shared-data-1308875761.cos.ap-beijing.myqcloud.com/artwork/docs/reference/right_join_where.png)|

- ``INNER JOIN``

|SELECT [select_list] FROM TableA A INNER JOIN TableB B ON A.Key=B.Key|![innerjoin](https://community-shared-data-1308875761.cos.ap-beijing.myqcloud.com/artwork/docs/reference/inner_join.png)|
|---|---|

- ``FULL JOIN``

|SELECT [select_list] FROM TableA A FULL OUTER JOIN TableB B ON A.Key=B.Key|![leftjoin](https://community-shared-data-1308875761.cos.ap-beijing.myqcloud.com/artwork/docs/reference/full_join.png)|
|---|---|
|SELECT [select_list] FROM TableA A FULL OUTER JOIN TableB B ON A.Key=B.Key WHERE A.Key IS NULL OR B.Key IS NULL|![fulljoinwhere](https://community-shared-data-1308875761.cos.ap-beijing.myqcloud.com/artwork/docs/reference/full_join_where.png)|

更多信息，参考：

- [LEFT JOIN](left-join.md)
- [RIGHT JOIN](right-join.md)
- [INNER JOIN](inner-join.md)
- [FULL JOIN](full-join.md)
- [OUTER JOIN](outer-join.md)
- [NATURAL JOIN](natural-join.md)
