# **UUID()**

## **函数说明**

`UUID()` 返回根据 [RFC 4122](http://www.ietf.org/rfc/rfc4122.txt) 生成国际通用唯一标识符 UUID(Universally Unique IDentifier)。

UUID 在空间和时间上是全球唯一的数字。即使是在两个未连接的独立运行的设备上执行 UUID 调用，预计会生成两个不同的值。

!!! info
    尽管 `UUID()` 值唯一，但它们并非是不可猜测或不可预测的。如果需要不可预测性，则应以其他方式生成 UUID 值。

`UUID()` 返回一个符合 [RFC 4122](http://www.ietf.org/rfc/rfc4122.txt) 标准的版本 1 UUID 的值，为 128 位数字，它表示是一个 utf8mb3 由五个十六进制数字组成的字符串，即 aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee，格式解释如下：

- 前三个数字是从时间戳的低、中和高部分生成的。高位部分还包括 UUID 版本号。

- 第四个数字保留时间唯一性，以防时间戳值失去单一性（例如，夏令时）。

- 第五个数字是空间唯一性的 IEEE 802 节点号。如果后者不可用（例如，因为主机设备没有以太网卡，或者不知道如何在主机操作系统上找到接口的硬件地址），则用随机数代替。在这种情况下，无法保证空间唯一性。然而，第五位数字重合的概率很低。

UUID 既是数据类型，也是函数，如需了解更多 UUID 数据类型，参见 [UUID 类型](../../Data-Types/uuid-type.md)。

## **函数语法**

```
> UUID()
```

## **示例**

```sql
drop table if exists t1;
create table t1(a INT,  b float);
insert into t1 values(12124, -4213.413), (12124, -42413.409);

mysql> SELECT length(uuid()) FROM t1;
+----------------+
| length(uuid()) |
+----------------+
|             36 |
|             36 |
+----------------+
2 rows in set (0.00 sec)

mysql> SELECT UUID();
+--------------------------------------+
| uuid()                               |
+--------------------------------------+
| b293b688-70a7-11ed-a25a-5ad2460dea50 |
+--------------------------------------+
1 row in set (0.00 sec)
```

## **限制**

`UUID()` 暂时不支持可选参数，即暂不支持 `UUID([number])`。
